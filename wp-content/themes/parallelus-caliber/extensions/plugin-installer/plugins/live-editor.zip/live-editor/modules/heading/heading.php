<?php

/**
 * @class FLRichTextModule
 */
class FEEHeadingModule extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Heading', 'fl-builder'),
			'description'   	=> __('Add text headings with titles and sub-titles.', 'fl-builder'),
			'category'      	=> __('Content', 'fl-builder'),
			'partial_refresh'	=> true
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FEEHeadingModule', array(
	'general'       => array( // Tab
		'title'         => __('General', 'fl-builder'), // Tab title
		'sections'      => array( // Tab Sections
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'pre_heading'  => array(
						'type'          => 'text',
						'label'         => __('Label', 'fl-builder'),
						'default'       => '',
						'help'          => __('A pre-headline text description for the section or title.', 'fl-builder'),
						'preview'         => array(
							'type'              => 'text',
							'selector'          => '.fee-pre-heading'
						)
					),
					'heading'  => array(
						'type'          => 'text',
						'label'         => __('Title', 'fl-builder'),
						'default'       => '',
						'help'          => __('The heading text. Use <em> elements to highlight words.', 'fl-builder'),
						'preview'         => array(
							'type'              => 'text',
							'selector'          => '.fee-heading'
						)
					),
					'lead'  => array(
						'type'          => 'textarea',
						'label'         => __('Sub Title', 'fl-builder'),
						'default'       => '',
						'help'          => __('Text to accompany the title for extra details or a description.', 'fl-builder'),
						'preview'         => array(
							'type'              => 'text',
							'selector'          => '.fee-lead'
						)
					)
				)
			),
			'options'   => array(
				'title'         => __('Options', 'fl-builder'),
				'fields'        => array(
					'heading_element'  => array(
						'type'          => 'select',
						'label'         => __('Heading Tag', 'fl-builder'),
						'default'       => 'h3',
						'options'       => array(
							'h1'        => __('H1', 'fl-builder'),
							'h2'        => __('H2', 'fl-builder'),
							'h3'        => __('H3', 'fl-builder'),
							'h4'        => __('H4', 'fl-builder'),
							'h5'        => __('H5', 'fl-builder'),
							'h6'        => __('H6', 'fl-builder'),
						),
						// 'help'          => __('', 'fl-builder'),
						'preview'         => array(
							'type'          => 'refresh'
						)
					),
					'heading_size'  => array(
						'type'          => 'select',
						'label'         => __('Heading Size', 'fl-builder'),
						'default'       => '',
						'options'       => array(
							''             => __('Normal', 'fl-builder'),
							'x2'           => __('Large', 'fl-builder'), // .x2 class added
						),
						'help'          => __('Show at normal size or make it larger.', 'fl-builder'),
						'preview'         => array(
							'type'          => 'refresh'
						)
					),
					'heading_align'  => array(
						'type'          => 'select',
						'label'         => __('Align Text', 'fl-builder'),
						'default'       => 'center',
						'options'       => array(
							'center'       => __('Center', 'fl-builder'),
							'left'         => __('Left', 'fl-builder'),
							'right'        => __('Right', 'fl-builder'),
						),
						// 'help'          => __('', 'fl-builder'),
						'preview'         => array(
							'type'          => 'refresh'
						)
					),
				)
			),
		)
	)
));