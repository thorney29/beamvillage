<?php
if (empty($settings->sidebar) && FLBuilderModel::is_builder_active()) :
// Empty, no sidebar and we're currently editing ?>
<div class="fl-sidebar" style="color: #ccccce; border: 3px dashed #dddddf; text-align:center; margin: 4px;">
	<div style="padding: 20px;">
		<i class="fa fa-columns fa-3x"></i>
	</div>
</div>
<?php elseif (!empty($settings->sidebar)):
	// We have a sidebar setting!
	if(!dynamic_sidebar($settings->sidebar)) {
		dynamic_sidebar();
	}
endif;