<?php
/*
Plugin Name: Live Editor
Plugin URI: http://para.llel.us
Description: A simple drag and drop frontend editor based on the brilliant Beaver Builder plugin.
Version: 0.8.0
Author: Parallelus
Author URI: http://para.llel.us
Text Domain: fl-builder
Domain Path: /languages/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Portions of this plugin are derived from Beaver Builder, which is released under the GPL2.
These unmodified sections are Copywritten 2014 Beaver Builder
*/

define('FL_BUILDER_VERSION', '0.8.0');
define('FL_BUILDER_FILE', __FILE__);
define('FL_BUILDER_DIR', plugin_dir_path(FL_BUILDER_FILE));
define('FL_BUILDER_URL', plugins_url('/', FL_BUILDER_FILE));
define('FL_BUILDER_LITE', true);
define('FL_BUILDER_SUPPORT_URL', '#');
define('FL_BUILDER_UPGRADE_URL', '#');
define('FL_BUILDER_DEMO_URL', '#');
define('FL_BUILDER_OLD_DEMO_URL', '#');
define('FL_BUILDER_DEMO_CACHE_URL', '#');

/* Classes */
require_once 'classes/class-fl-builder.php';
require_once 'classes/class-fl-builder-admin.php';
require_once 'classes/class-fl-builder-admin-posts.php';
require_once 'classes/class-fl-builder-ajax.php';
require_once 'classes/class-fl-builder-ajax-layout.php';
require_once 'classes/class-fl-builder-auto-suggest.php';
require_once 'classes/class-fl-builder-color.php';
require_once 'classes/class-fl-builder-fonts.php';
require_once 'classes/class-fl-builder-icons.php';
require_once 'classes/class-fl-builder-loop.php';
require_once 'classes/class-fl-builder-model.php';
require_once 'classes/class-fl-builder-module.php';
require_once 'classes/class-fl-builder-photo.php';
require_once 'classes/class-fl-builder-services.php';
require_once 'classes/class-fl-builder-shortcodes.php';
require_once 'classes/class-fl-builder-update.php';
require_once 'classes/class-fl-builder-timezones.php';
require_once 'classes/class-fl-builder-utils.php';

/* Includes */
require_once 'includes/compatibility.php';
require_once 'includes/updater/updater.php';

/* Plugin Activation */
register_activation_hook(__FILE__,                             'FLBuilderAdmin::activate');

/* Localization */
add_action('plugins_loaded',                                   'FLBuilder::load_plugin_textdomain');

/* Updates */
add_action('init',                                             'FLBuilderUpdate::init', 11);

/* Load Settings and Modules */
add_action('init',                                             'FLBuilderModel::load_settings', 1);
add_action('init',                                             'FLBuilderModel::load_modules', 2);

/* Admin AJAX */
add_action('wp_ajax_fl_builder_disable',                       'FLBuilderModel::disable');
add_action('wp_ajax_fl_builder_duplicate_wpml_layout',         'FLBuilderModel::duplicate_wpml_layout');

/* Admin Actions */
add_action('init',                                             'FLBuilderAdmin::init');
add_action('current_screen',                                   'FLBuilderAdminPosts::init');
add_action('before_delete_post',                               'FLBuilderModel::delete_post');
add_action('save_post',                                        'FLBuilderModel::save_revision');
add_action('save_post',                    					   'FLBuilderModel::set_node_template_default_type', 10, 3);
add_action('wp_restore_post_revision',                         'FLBuilderModel::restore_revision', 10, 2);

/* Admin Filters */
add_filter('heartbeat_received',                               'FLBuilderModel::lock_post', 10, 2);
add_filter('redirect_post_location',                           'FLBuilderAdminPosts::redirect_post_location');
add_filter('page_row_actions',                                 'FLBuilderAdminPosts::render_row_actions_link');
add_filter('post_row_actions',                                 'FLBuilderAdminPosts::render_row_actions_link');
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'FLBuilderAdmin::render_plugin_action_links');
add_filter('all_plugins',                                      'FLBuilderAdmin::white_label_plugins_page');
add_filter('wp_prepare_themes_for_js',                         'FLBuilderAdmin::white_label_themes_page');
add_filter('gettext', 										   'FLBuilderAdmin::white_label_theme_gettext');

/* Frontend AJAX */
add_action('wp', 											   'FLBuilderAJAX::init');

/* Frontend Actions */
add_action('init',                                             'FLBuilder::register_templates_post_type');
add_action('send_headers',                                     'FLBuilder::no_cache_headers');
add_action('wp',                                               'FLBuilder::init');
add_action('wp_enqueue_scripts',                               'FLBuilder::layout_styles_scripts');
add_action('wp_enqueue_scripts',                               'FLBuilder::styles_scripts');
add_action('wp_head',                                  		   'FLBuilder::render_custom_css_for_editing', 999);
add_action('admin_bar_menu',                                   'FLBuilder::admin_bar_menu', 999);
add_action('wp_footer',                                        'FLBuilder::include_jquery');
add_action('wp_footer',                                        'FLBuilder::render_ui');

/* Frontend Filters */
add_filter('found_posts',                                      'FLBuilderLoop::found_posts', 1, 2);
add_filter('template_include',                                 'FLBuilder::render_template', 999);
add_filter('body_class',                                       'FLBuilder::body_class');
add_filter('wp_default_editor',                                'FLBuilder::default_editor');
add_filter('mce_css',                                          'FLBuilder::add_editor_css');
add_filter('mce_buttons_2',                                    'FLBuilder::editor_buttons_2');
add_filter('mce_external_plugins',                             'FLBuilder::editor_external_plugins', 9999);
add_filter('tiny_mce_before_init',                             'FLBuilder::editor_font_sizes');
add_filter('the_content',                                      'FLBuilder::render_content');