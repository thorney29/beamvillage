<div<?php FLBuilder::render_row_attributes( $row ); ?>>
	<div class="<?php echo esc_attr(apply_filters('fee_container_wrap_class', 'fe-container-wrap')) ?>">
		<?php FLBuilder::render_row_bg( $row ); ?>
		<div class="<?php FLBuilder::render_row_content_class( $row ); ?>">
		<?php
// out($groups);
		foreach ( $groups as $group ) {
			FLBuilder::render_column_group( $group );
		}

		?>
		</div>
	</div>
</div>