<?php

if(class_exists('FLUpdater')) {
	FLUpdater::add_product(array(
		'name'      => 'Beaver Builder Plugin (Lite Version)', 
		'version'   => '1.7.1', 
		'slug'      => 'bb-plugin',
		'type'      => 'plugin'
	)); 
}