<div class="wrap <?php FLBuilderAdminSettings::render_page_class(); ?>">

	<h2 class="fl-settings-heading">
		<?php FLBuilderAdminSettings::render_page_heading(); ?>
	</h2>

	<?php FLBuilderAdminSettings::render_update_message(); ?>

	<h2 class="fl-settings-nav nav-tab-wrapper tab-controlls">
		<!-- <ul> -->
			<?php FLBuilderAdminSettings::render_nav_items(); ?>
		<!-- </ul> -->
	</h2>

	<div class="fl-settings-content">
		<?php FLBuilderAdminSettings::render_forms(); ?>
	</div>
</div>