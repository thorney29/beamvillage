<?php
if (empty($settings->text) && FLBuilderModel::is_builder_active()) :
// Empty, no text and we're currently editing ?>
<div class="fl-rich-text" style="color: #ccccce; border: 3px dashed #dddddf; text-align:center; margin: 4px;">
	<div style="padding: 20px;">
		<i class="fa fa-font fa-3x"></i>
	</div>
</div>
<?php else:
// We have text! ?>
<div class="fl-rich-text">
	<?php echo $settings->text; ?>
</div>
<?php
endif;