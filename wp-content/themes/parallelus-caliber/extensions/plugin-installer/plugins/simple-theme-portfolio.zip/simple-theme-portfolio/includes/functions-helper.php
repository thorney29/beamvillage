<?php
/*
	Helper functions to be used by themes for portfolio templates.
*/

#-----------------------------------------------------------------
# Custom filter for next/previous portfolio items (sorted by menu order)
#-----------------------------------------------------------------

function st_portfolio_next_previous_item( $text = false, $direction = 'next', $return_id = false ) {

	// Get the portfolio items
	$portfolios = get_posts(array(
		'post_type'=>'portfolio',
		'orderby' => 'menu_order',
		'order' => 'ASC',
		'posts_per_page' => -1
	));
	$direction = ($direction == 'previous' || $direction == 'prev') ? 'prev' : 'next';
	$text = ($text) ? $text : ucwords($direction);

	if( has_filter('wpml_items', array('ST_Portfolio_CPT', 'wpml_items')) )
		$portfolios = apply_filters( 'wpml_items', $portfolios, 'portfolio' );

	// Add all portfolio ID's to an array
	$items = array();
	foreach ($portfolios as $item) {
	   $items[] += $item->ID;
	}

	// Curent item ID
	$current = array_search(get_the_ID(), $items);

	// we don't "loop" front to end so if it's the first or last we're done.
	if ( ($current === 0 && $direction == 'prev') || ($current == count($items)-1 && $direction == 'next') || $current === false) {
		// ID of post only
		if ($return_id)
			return false;

		// Make the static arrow
		$navArrow = '<span class="meta-nav disabled">'.$text.'</span>';
	} else {
		// Get the next/previous item in the array
		$navID = ($direction == 'prev') ? $items[$current-1] : $items[$current+1];

		// ID of post only
		if ($return_id)
			return $navID;

		// Make the link
		$navArrow = '<a href="'.get_permalink($navID).'" rel="'.$direction.'"><span class="meta-nav">'.$text.'</span></a>';
	}

	// send it back
	return $navArrow;

}

// Next Portfolio Item
function st_portfolio_next_item( $text = '&rsaquo;', $direction = 'next' ) {
	echo st_portfolio_next_previous_item( $text, $direction);
}
// Previous Portfolio Item
function st_portfolio_prev_item( $text = '&lsaquo;', $direction = 'prev' ) {
	echo theme_next_previous_portfolio_item( $text, $direction);
}
