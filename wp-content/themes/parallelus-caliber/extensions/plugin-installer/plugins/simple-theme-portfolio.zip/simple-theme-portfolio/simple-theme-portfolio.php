<?php
/*
	Plugin Name: Simple Theme Portfolio
	Plugin URI: http://para.llel.us
	Version: 1.0.0
	Description: A simple portfolio creator for your theme.
	Author: Parallelus
	Author URI: http://para.llel.us
	Copyright: 2016 Parallelus
	License: GNU General Public License v2.0
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
	Text Domain: st_portfolio
*/

/* global variables */

// Plugin version
if ( ! defined( 'ST_PORTFOLIO_VERSION' ) ) {
	define( 'ST_PORTFOLIO_VERSION', '1.0.0' );
}
// Plugin Folder Path
if ( ! defined( 'ST_PORTFOLIO_PLUGIN_DIR' ) ) {
	define( 'ST_PORTFOLIO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
// Plugin Folder URL
if ( ! defined( 'ST_PORTFOLIO_PLUGIN_URL' ) ) {
	define( 'ST_PORTFOLIO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
// Plugin Root File
if ( ! defined( 'ST_PORTFOLIO_PLUGIN_FILE' ) ) {
	define( 'ST_PORTFOLIO_PLUGIN_FILE', __FILE__ );
}

/* Classes */
require_once( plugin_dir_path( __FILE__ ) . 'classes/class-portfolio.php' );
require_once( plugin_dir_path( __FILE__ ) . 'classes/class-walker.php' );

/* Includes */
require_once( plugin_dir_path( __FILE__ ) . 'includes/functions-helper.php' );

/* Plugin Activation */
register_activation_hook( __FILE__, 'ST_Portfolio_CPT::activate' );
