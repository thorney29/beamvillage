<?php
// prevents direct folder access
