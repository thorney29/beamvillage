<?php
/*
	The Portfolio Class
*/

#-----------------------------------------------------------------
# Create the Portfolio Class
#-----------------------------------------------------------------
if( ! class_exists( 'ST_Portfolio_CPT' ) ) {
	class ST_Portfolio_CPT {

		public function __construct() {

			$this->init();
		}

		private function init() {
			$this->setup_constants();

			add_action( 'plugins_loaded', array( $this, 'load_languages' ), 11 );
			add_action( 'init', array( $this, 'register_post_type' ), 100 );
			add_action( 'init', array( $this, 'register_taxonomy' ), 101 );
			add_action( 'init', array( $this, 'flush_rewrite_rules' ), 102 );

			add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes_function' ) );
			add_action( 'save_post', array( $this, 'save_meta_box_data' ) );
			add_action( 'admin_menu', array( $this, 'create_sort_page') );
			add_action( 'wp_ajax_portfolio_sort', array( $this, 'save_sort_order') );

			// Custom admin listing (columns, order, etc)
			add_filter( 'manage_edit-portfolio_columns', array( $this, 'portfolio_edit_columns') );
			add_action( 'manage_posts_custom_column', array( $this, 'portfolio_custom_columns') );
			add_filter( 'pre_get_posts', array( $this, 'portfolio_admin_rows_order') );

			// WPML support
			add_filter( 'wpml_items', array( $this, 'wpml_items'), 10, 2 );

		}

		private function setup_constants() {
			// nothing here...
		}

		// Upon plugin activation (used by 'register_activation_hook')
		//...............................................
		public function activate() {
			// Set flag to make sure rewrite rules are flushed after loading
			ST_Portfolio_CPT::flush_rewrite_rules(true);
		}

		/**
		 * Load our language files
		 *
		 * @access public
		 * @return void
		 */
		public function load_languages() {
			// Set unique textdomain string
			$textdomain = 'st_portfolio';

			// The 'plugin_locale' filter is also used by default in load_plugin_textdomain()
			$locale = apply_filters( 'plugin_locale', get_locale(), $textdomain );

			// Set filter for WordPress languages directory
			$wp_lang_dir = apply_filters( 'st_portfolio_wp_lang_dir', WP_LANG_DIR . '/st_portfolio/' . $textdomain . '-' . $locale . '.mo' );

			// Translations: First, look in WordPress' "languages" folder
			load_textdomain( $textdomain, $wp_lang_dir );

			// Translations: Next, look in plugin's "lang" folder (default)
			$plugin_dir = basename( dirname( __FILE__ ) );
			$lang_dir = apply_filters( 'st_portfolio_lang_dir', $plugin_dir . '/languages/' );
			load_plugin_textdomain( $textdomain, FALSE, $lang_dir );
		}

		// Create the Portfolio Custom Post Type
		//...............................................
		public function register_post_type() {

			$labels = array(
				'name'               => __( 'Portfolio','st_portfolio'),
				'singular_name'      => __( 'Portfolio','st_portfolio' ),
				'add_new'            => __('Add New','st_portfolio'),
				'add_new_item'       => __('Add New Portfolio','st_portfolio'),
				'edit_item'          => __('Edit Portfolio','st_portfolio'),
				'new_item'           => __('New Portfolio','st_portfolio'),
				'view_item'          => __('View Portfolio','st_portfolio'),
				'search_items'       => __('Search Portfolio','st_portfolio'),
				'not_found'          =>  __('No portfolio found','st_portfolio'),
				'not_found_in_trash' => __('No portfolio found in Trash','st_portfolio'),
				'parent_item_colon'  => ''
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'has_archive'         => true,
				'exclude_from_search' => false,
				'publicly_queryable'  => true,
				'show_ui'             => true,
				'query_var'           => true,
				'capability_type'     => 'page',
				'hierarchical'        => false,
				'menu_icon'           => 'dashicons-format-gallery', // 'dashicons-images-alt2',
				'menu_position'       => null,
				// Uncomment and change value for custom URL slug. Re-save permalinks after editing to prevent 404 errors.
				// 'rewrite'             => array( 'slug' => 'portfolio' ),
				'rewrite'             => array('with_front' => false),
				'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'post-formats') /* ,'custom-fields' */
			);

			register_post_type(__( 'portfolio', 'st_portfolio' ),$args);

			// This just uses WP to store some information that we're going to reference later so we can emulate
			// different post FORMAT support for different post TYPES (requires Post Formats extension for Runway Framework)
			$supported_formats = apply_filters('st_portfolio_post_formats', array('gallery', 'audio', 'video'));
			add_post_type_support( 'portfolio', 'post-formats', $supported_formats );
		}

		// Create the Portfolio Category Taxonomy
		//...............................................
		public function register_taxonomy() {
			$labels = array(
				'name'                       => __( 'Portfolio Category', 'st_portfolio' ),
				'singular_name'              => __( 'Portfolio Category', 'st_portfolio' ),
				'search_items'               =>  __( 'Search Portfolio Categories', 'st_portfolio' ),
				'popular_items'              => __( 'Popular Portfolio Categories', 'st_portfolio' ),
				'all_items'                  => __( 'All Portfolio Categories', 'st_portfolio' ),
				'parent_item'                => __( 'Parent Portfolio Category', 'st_portfolio' ),
				'parent_item_colon'          => __( 'Parent Portfolio Category:', 'st_portfolio' ),
				'edit_item'                  => __( 'Edit Portfolio Category', 'st_portfolio' ),
				'update_item'                => __( 'Update Portfolio Category', 'st_portfolio' ),
				'add_new_item'               => __( 'Add New Portfolio Category', 'st_portfolio' ),
				'new_item_name'              => __( 'New Portfolio Category Name', 'st_portfolio' ),
				'separate_items_with_commas' => __( 'Separate categories with commas', 'st_portfolio' ),
				'add_or_remove_items'        => __( 'Add or remove categories', 'st_portfolio' ),
				'choose_from_most_used'      => __( 'Choose from the most frequent portfolio categories', 'st_portfolio' ),
				'menu_name'                  => __( 'Portfolio Categories', 'st_portfolio' )
			);

			register_taxonomy(
				'portfolio-category',
				array( __( 'portfolio', 'st_portfolio' )),
				array(
					'hierarchical' => true,
					'labels'       => $labels,
					'show_ui'      => true,
					'query_var'    => true,
					'rewrite'      => array('slug' => 'portfolio-category', 'hierarchical' => true)
				)
			);
		}

		// Sets flag and performs rewrite rule flushing when needed
		//...............................................
		public function flush_rewrite_rules( $set_flag = false ) {
			// Check if we need to flush the rules
			if ( !$set_flag && get_option('st_portfolio_flush_rules_flag') ) {
				flush_rewrite_rules();
				delete_option('st_portfolio_flush_rules_flag');
			} elseif ($set_flag) {
				// Set a flag to flush on next load
				update_option( 'st_portfolio_flush_rules_flag', true );
			}
		}

		// Meta Boxes
		//...............................................
		public function get_meta_boxe_info() {

			$meta_box_info = array(
				'id' => 'theme-meta-box-portfolio',
				'title' =>  __('Portfolio Detail Settings', 'st_portfolio'),
				'page' => 'portfolio',
				'context' => 'normal',
				'priority' => 'default',
				'fields' => array(
					array(
						'name' => __('Show Extra Details', 'st_portfolio'),
						'desc' => __('Show the extra details on the portfolio page.', 'st_portfolio'),
						'id' => 'st_portfolio_show_details',
						'type' => 'select',
						'std' => '',
						'options' => array(
							'hide' => 'Hide',
							'show' => 'Show'
						)
					),
					array(
						'name' => __('Extra Details', 'st_portfolio'),
						'desc' => __('Use this area for additional details specific to this project.', 'st_portfolio'),
						'id' => 'st_portfolio_details',
						'type' => 'textarea',
						'std' => ''
					)
				)
			);

			return $meta_box_info;

		}

		// Add Meta Boxes
		public function add_meta_boxes_function() {

			$meta_box_info = $this->get_meta_boxe_info();

			add_meta_box(
				$meta_box_info['id'],
				$meta_box_info['title'],
				array( $this, 'render_meta_boxes' ), // 'theme_show_box_portfolio',
				$meta_box_info['page'],
				$meta_box_info['context'],
				$meta_box_info['priority']
			);

		}

		// Callback function to show fields in meta box
		public function render_meta_boxes() {
			global $post;

			$meta_box_info = $this->get_meta_boxe_info();

			echo '<p style="padding:10px 0 0 0;">'.__('Optionally add extra details for this item.', 'st_portfolio').'</p>';
			echo '<input type="hidden" name="theme_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
			echo '<table class="form-table">';

			foreach ($meta_box_info['fields'] as $field) {
				// get current post meta data
				$meta = get_post_meta($post->ID, $field['id'], true);
				switch ($field['type']) {

					// Select box
					case 'select':
					echo '<tr style="border-top:1px solid #eeeeee;" id="'.$field['id'].'_row">',
						'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong></label></th>',
						'<td>';
						echo '<div class="metaField_field_wrapper metaField_field_'.$field['id'].'">',
							 '<select class="metaField_select" id="'.$field['id'].'"  name="'.$field['id'].'">';
						$count = 0;
						foreach ($field['options'] as $key => $label) {
							$selected = ($meta == $key || (!$meta && !$count)) ? 'selected="selected"' : '';
							echo '<option value="'.$key.'" '.$selected.'>'.$label.'</option>';
							$count++;
						}
						echo '</select>';
						if ($field['desc']) { echo '<p class="metaField_caption" style="color:#999">'.$field['desc'].'</p>'; }
						echo '</div>';
					echo '</td></tr>';
					break;

					// Text
					case 'text':
					echo '<tr style="border-top:1px solid #eeeeee;" id="'.$field['id'].'_row">',
						'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">'. $field['desc'].'</span></label></th>',
						'<td>';
					echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
					echo '</td></tr>';
					break;

					// Textarea
					case 'textarea':
					echo '<tr style="border-top:1px solid #eeeeee;" id="'.$field['id'].'_row">',
						'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style="line-height:18px; display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
						'<td>';
					echo '<textarea name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : $field['std'], '" rows="8" cols="5" style="width:100%; margin-right: 20px; float:left;">', $meta ? $meta : $field['std'], '</textarea>';
					echo '</td></tr>';
					break;

				}
			}
			echo '</table>';

			// Show hide details fields
			echo '<script>';
			echo "jQuery(document).ready(function (\$) {
			detailsSelect = \$('#st_portfolio_show_details');
			detailsSelect.on('change', function() {
				detailFields = '#st_portfolio_details_row';
				console.log(\$(this).val());
				if (\$(this).val() == 'hide') {
					\$(detailFields).fadeOut();
				} else {
					\$(detailFields).fadeIn()
				}
			});
			detailsSelect.trigger('change');
		});";
			echo '</script>';

		}

		// Save Meta Box Data
		public function save_meta_box_data( $post_id ) {
			global $post;

			$meta_box_info = $this->get_meta_boxe_info();

			// verify nonce
			if ( !isset($_POST['theme_meta_box_nonce']) || !wp_verify_nonce($_POST['theme_meta_box_nonce'], basename(__FILE__))) {
				return $post_id;
			}

			// check permissions
			if (!current_user_can('edit_post', $post_id)) {
				return $post_id;
			}

			foreach ($meta_box_info['fields'] as $field) {
				$old = get_post_meta($post_id, $field['id'], true);
				$new = $_POST[$field['id']];

				if ($new && $new != $old) {
					update_post_meta($post_id, $field['id'], stripslashes(htmlspecialchars($new)));
				} elseif ('' == $new && $old) {
					delete_post_meta($post_id, $field['id'], $old);
				}
			}
		}


		// Enable Sorting of the Portfolio
		//...............................................
		public function create_sort_page() {
			$theme_sort_page = add_submenu_page( 'edit.php?post_type=portfolio', 'Sort Items', __('Sort Items', 'st_portfolio'), 'edit_posts', basename(__FILE__), array( $this, 'portfolio_sort') );

			add_action( 'admin_print_styles-' . $theme_sort_page, array( $this, 'print_sort_styles') );
			add_action( 'admin_print_scripts-' . $theme_sort_page, array( $this, 'print_sort_scripts') );
		}

		// Sorting JS
		public function print_sort_scripts() {
			wp_enqueue_script('jquery-ui-sortable');
			wp_enqueue_script('portfolio_sort', ST_PORTFOLIO_PLUGIN_URL . '/assets/js/sort.js');
		}

		// Sorting CSS
		public function print_sort_styles() {
			wp_enqueue_style('nav-menu');
		}

		// Output the Admin Sort Page Content
		public function portfolio_sort() {
			$portfolios = new WP_Query('post_type=portfolio&posts_per_page=-1&orderby=menu_order&order=ASC');
			?>
			<div class="wrap">
				<div id="icon-tools" class="icon32"><br /></div>
				<h2><?php _e('Sort Portfolio Items', 'st_portfolio'); ?></h2>
				<p><?php _e('Drag portfolio items to organize.', 'st_portfolio'); ?></p>

				<ul id="portfolio_list">
					<?php while( $portfolios->have_posts() ) : $portfolios->the_post(); ?>
						<?php if( get_post_status() == 'publish' ) { ?>
							<li id="<?php the_id(); ?>" class="menu-item">
								<dl class="menu-item-bar">
									<dt class="menu-item-handle">
										<span class="menu-item-title"><?php the_title(); ?></span>
									</dt>
								</dl>
								<ul class="menu-item-transport"></ul>
							</li>
						<?php } ?>
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
				</ul>
			</div>
			<?php
		}

		// Ajax function called to save sort order
		public function save_sort_order() {
			global $wpdb;

			$order = explode(',', $_POST['order']);
			$counter = 0;

			foreach($order as $portfolio_id) {
				$wpdb->update($wpdb->posts, array('menu_order' => $counter), array('ID' => $portfolio_id));
				$counter++;
			}
			die(1);
		}


		// Customize admin portfolio list
		//...............................................
		public function portfolio_edit_columns( $columns ){
				$columns = array(
					"cb" => "<input type=\"checkbox\" />",
					"title" => __( 'Portfolio Item Title', 'st_portfolio' ),
					"type" => __( 'Categories', 'st_portfolio' ),
					"order" => __( 'Order', 'st_portfolio' )
				);

				return $columns;
		}
		public function portfolio_custom_columns( $column ){
				global $post;
				switch ($column) {
					case __( 'type', 'st_portfolio' ):
						echo get_the_term_list($post->ID, __( 'portfolio-category', 'st_portfolio' ), '', ', ','');
						break;
				}
		}
		public function portfolio_admin_rows_order( $wp_query ) {
			if (is_admin()) {
				// Get the post type from the query
				$post_type = $wp_query->query['post_type'];
				// if it's one of our custom ones
				if ( $post_type == 'portfolio') {
					$wp_query->set('orderby', 'menu_order');
					$wp_query->set('order', 'ASC');
				}
			}
		}


		// WPML Compatibility
		//...............................................
		public function wpml_items($items, $type) {
			if(defined('ICL_LANGUAGE_CODE')) {
				$wpml_items = array();
				foreach($items as $key => $item) {
					if($item->ID == icl_object_id($item->ID, $type, true, ICL_LANGUAGE_CODE))
						$wpml_items[] = $item;
				}
				return $wpml_items;
			}

			return $items;
		}
	}
}

#-----------------------------------------------------------------
# Load the Portfolio Class
#-----------------------------------------------------------------
function st_portfolio_load() {
	$portfolio = new ST_Portfolio_CPT();
}
add_action( 'plugins_loaded', 'st_portfolio_load' );

