<div id="nf-form-<?php echo $form_id; ?>-cont">
    
    <div class="nf-loading-spinner"></div>

</div>