<h4>Submission Data</h4>

<?php
echo "<pre>";
var_dump($data);
echo "</pre>";
?>